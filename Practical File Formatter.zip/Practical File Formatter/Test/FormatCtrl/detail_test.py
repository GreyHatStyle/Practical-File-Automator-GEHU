from Utils import Format_Ctrl_Utils

lst = ["Manas Bisht", "38", "E1", "B.Tech"]

a = Format_Ctrl_Utils()
str = a.person_details_formatter(lst)
print(str)

# Passed!