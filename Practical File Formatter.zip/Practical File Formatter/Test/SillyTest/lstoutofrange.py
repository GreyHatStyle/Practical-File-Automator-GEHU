lst = ['main.c', 'main2.c', 'main3.c']

print(lst[3])